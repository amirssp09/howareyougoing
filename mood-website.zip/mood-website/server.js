const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

// Middleware برای پردازش JSON
app.use(express.json());

// سرویس فایل‌های استاتیک از پوشه public
app.use(express.static(path.join(__dirname, 'public')));

// دیتای نمونه برای محتوا
const contentData = {
    happy: {
        companion: {
            song: "https://dl.rozmusic.com/Music/1397/09/25/Ashvan%20-%20Sheyda%20(128).mp3",
            songName: "شیدا",
            artist: "اشوان",
           // image: "https://example.com/images/happy-companion.jpg"
        },
        improve: {
            song: "https://dl.shabamusic.com/Music/1402/09/06/Hassan%20Shameezadeh%20-%20Bishtar%20Bishtar%20(128).mp3",
            songName: "بیشتر و بیشتر",
            artist: " حسن شماعی زاده",
           // image: "https://example.com/images/happy-improve.jpg"
        }
    },
    sad: {
        companion: {
            song: "https://musictaj.musicmellnet.com/song403/zmstn/Hiphopologist%20-%20Bad%20Zaat.mp3",
            songName: " بد زات",
            artist: "هیپهاپولوژیست",
            image: "https://example.com/images/sad-companion.jpg"
        },
        improve: {
            song: "https://radiodl2.musicmelnet.com/Music/1400/8/habib.mohebian.Bezan.Baran(320).mp3?_=1",
            songName: "بزن باران",
            artist: "حبیب",
            image: "https://example.com/images/sad-improve.jpg"
        }
    },
    neutral: {
        companion: {
            song: "https://dldbmu.musicmellnet.com/dl/1401/08/TM-Bax-Masalei-Ni-dibamusics.com-320.mp3",
            songName: "مسئله ای نی",
            artist: "تی ام بکس",
            image: "https://example.com/images/neutral-companion.jpg"
        },
        improve: {
            song: "https://irsv.upmusics.com/dlw/Erfan%20Tahmasbi%20-%20Hezaro%20Yek%20Shab%20(320).mp3",
            songName: "هزار و یک شب",
            artist: "عرفان طهماسبی",
            image: "/home/amir/mood-website/images.jpeg"
        }
    }
};

// روت برای دریافت محتوا
app.post('/get-content', (req, res) => {
    const { mood, mode } = req.body; // حال و حالت کاربر
    if (!mood || !contentData[mood] || !mode) {
        return res.status(400).json({ error: 'درخواست نامعتبر است.' });
    }

    // ارسال محتوای متناسب با حال و حالت کاربر
    res.json(contentData[mood][mode]);
});

// شروع سرور
app.listen(port, () => {
    console.log(`سرور در حال اجرا است: http://localhost:${port}`);
});