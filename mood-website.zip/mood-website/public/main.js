document.addEventListener('DOMContentLoaded', () => {
    // تغییر تم (دارک/لایت)
    document.querySelectorAll('.theme-button').forEach(button => {
        button.addEventListener('click', () => {
            // حذف کلاس active از همه دکمه‌های تم
            document.querySelectorAll('.theme-button').forEach(btn => btn.classList.remove('active'));
            // اضافه کردن کلاس active به دکمه انتخاب‌شده
            button.classList.add('active');
            // اعمال تم
            document.body.className = button.dataset.theme === 'dark' ? 'dark' : '';
        });
    });

    // تغییر حالت (بهبود حال/همراهی)
    document.querySelectorAll('.mode-button').forEach(button => {
        button.addEventListener('click', () => {
            // حذف کلاس active از همه دکمه‌های حالت
            document.querySelectorAll('.mode-button').forEach(btn => btn.classList.remove('active'));
            // اضافه کردن کلاس active به دکمه انتخاب‌شده
            button.classList.add('active');
        });
    });

    // ارسال فرم
    const form = document.getElementById('moodForm');
    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            // دریافت حال کاربر
            const mood = document.getElementById('mood').value;

            // دریافت تم انتخاب‌شده
            const activeThemeButton = document.querySelector('.theme-button.active');
            const theme = activeThemeButton ? activeThemeButton.dataset.theme : 'light';

            // دریافت حالت انتخاب‌شده
            const activeModeButton = document.querySelector('.mode-button.active');
            const mode = activeModeButton ? activeModeButton.dataset.mode : 'improve';

            // اعمال تم
            document.body.className = theme === 'dark' ? 'dark' : '';

            try {
                // ارسال درخواست به سرور
                const response = await fetch('/get-content', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ mood, mode }) // ارسال حال و حالت
                });

                const data = await response.json();
                console.log('داده‌های برگشتی:', data); // بررسی داده‌های برگشتی

                // نمایش محتوا
                const songInfo = document.getElementById('songInfo');
                if (songInfo) {
                    songInfo.textContent = `آهنگ: ${data.songName} - خواننده: ${data.artist}`;
                } else {
                    console.error('عنصر songInfo پیدا نشد!');
                }

                const image = document.getElementById('image');
                if (image) {
                    image.src = data.image;
                } else {
                    console.error('عنصر image پیدا نشد!');
                }

                const song = document.getElementById('song');
                if (song) {
                    song.querySelector('source').src = data.song;
                    song.load();
                } else {
                    console.error('عنصر song پیدا نشد!');
                }

                const content = document.getElementById('content');
                if (content) {
                    content.classList.remove('hidden');
                } else {
                    console.error('عنصر content پیدا نشد!');
                }
            } catch (error) {
                console.error('خطا در دریافت محتوا:', error);
            }
        });
    } else {
        console.error('فرم پیدا نشد!');
    }
});